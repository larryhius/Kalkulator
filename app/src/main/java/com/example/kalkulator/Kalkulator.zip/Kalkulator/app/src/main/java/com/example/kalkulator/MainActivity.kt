package com.example.kalkulator

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.example.kalkulator.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.xml.activity_main)
    }

    fun openMvcCalculator(view: View) {
        val webView = findViewById<WebView>(R.id.webView)
        // Menampilkan WebView dan memuat XML dari folder res/xml
        webView.visibility = View.VISIBLE
        webView.loadUrl("file:///android_res/xml/activity_mvc_calculator.xml")  // Ganti dengan path XML sesuai kebutuhan
    }

    fun openMvvmCalculator(view: View) {
        val webView = findViewById<WebView>(R.id.webView)
        // Menampilkan WebView dan memuat XML dari folder res/xml
        webView.visibility = View.VISIBLE
        webView.loadUrl("file:///android_res/xml/activity_mvvm_calculator.xml")  // Ganti dengan path XML sesuai kebutuhan
    }
}